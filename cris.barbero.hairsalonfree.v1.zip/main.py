import random
import datetime


class CustomerBuilder:
    def __init__(self):
        self.count = 0
        self.mins_until_next_customer = 0

    def try_get_new_customer(self):
        '''Returns a new customer on a random schedule'''

        if self.mins_until_next_customer == 0:
            # Next customer will arrive between 5 and 15 minutes from now
            self.mins_until_next_customer = random.randint(5,15)
            self.count += 1
            return f'Customer_{self.count}'
        else:
            self.mins_until_next_customer-=1

class Stylist:
    def __init__(self, name):
        self.name = name

    def get_name(self):
        return self.name


class HairSalon:
    def __init__(self, time):
        self.is_open = False
        self.time = time
        self.first_shift_stylists = [
            Stylist('Anne'),
            Stylist('Ben'),
            Stylist('Carol'),
            Stylist('Derek')
        ]
        self.second_shift_stylists = [
            Stylist('Erin'),
            Stylist('Frank'),
            Stylist('Gloria'),
            Stylist('Heber')
        ]
        self.working_stylists = []
        self.free_stylists = []
        self.waiting_customers = []
        self.active_hair_cuts = []
        self.overtime_stylists = []

    def total_customers(self):
        return (len(self.waiting_customers) + len(self.active_hair_cuts))

    def open(self):
        self.is_open = True
        print(f'[{self.time.current_time_to_string()}] Hair salon [opened]')

    def close(self):
        self.is_open = False
        print(f'[{self.time.current_time_to_string()}] Hair salon [closed]')

    def first_shift_starts(self):
        for sylist in self.first_shift_stylists:
            self.stylist_clock_in(sylist)

    def first_shift_ends(self):
        # clock out each free first shift stylist
        # if any are working, then check back on them when they finish
        for stylist in self.first_shift_stylists:
            if stylist in self.free_stylists:
                self.free_stylists.remove(stylist)
            else:
                self.overtime_stylists.append(stylist)

    def second_shift_starts(self):
        for sylist in self.second_shift_stylists:
            self.stylist_clock_in(sylist)

    def second_shift_ends(self):
        # clock out each free second shift stylist
        # if any are working, then check back on them when they finish
        for stylist in self.second_shift_stylists:
            if stylist in self.free_stylists:
                self.free_stylists.remove(stylist)
            else:
                self.overtime_stylists.append(stylist)

    def stylist_clock_in(self, stylist):
        self.working_stylists.append(stylist)
        self.free_stylists.append(stylist)
        print(
            f'[{self.time.current_time_to_string()}] [{stylist.get_name()}] [started] shift')

    def stylist_clock_out(self, stylist):
        self.working_stylists.remove(stylist)
        if stylist in self.free_stylists:
            self.free_stylists.remove(stylist)
        print(
            f'[{self.time.current_time_to_string()}] [{stylist.get_name()}] [ended] shift')

    def print_working_stylists(self):
        for stylist in self.working_stylists:
            print(stylist.get_name())

    def customer_enter(self, name):
        print(f'[{self.time.current_time_to_string()}] [{name}] entered')
        if self.total_customers() == 15:
            print(
                f'[{self.time.current_time_to_string()}] [{name}] left [impatiently]')
        elif self.time.is_after_hour(17):
            print(
                f'[{self.time.current_time_to_string()}] [{name}] left [cursing themselves]')
        else:
            self.waiting_customers.append({'name': name, 'time_waiting': 0})

    def customer_leaves_unfulfilled(self, waiting_customer):
        self.waiting_customers.remove(waiting_customer)
        print(f'[{self.time.current_time_to_string()}] [{waiting_customer["name"]}] left [unfulfilled]')

    def finish_hair_cut(self, hair_cut):
        print(
            f'[{self.time.current_time_to_string()}] [{hair_cut["customer"]}] left [satisfied]')
        self.active_hair_cuts.remove(hair_cut)
        if hair_cut['stylist'] in self.overtime_stylists:
            self.stylist_clock_out(hair_cut['stylist'])
        else:
            self.free_stylists.append(hair_cut['stylist'])

    def service_next_customer(self):
        stylist = self.free_stylists.pop()
        waiting_customer = self.waiting_customers.pop()
        hair_cut_time = random.randint(20, 40)
        self.active_hair_cuts.append({'customer': customer,
                                      'stylist': stylist,
                                      'time_remaining': hair_cut_time})
        print(
            f'[{self.time.current_time_to_string()}] [{stylist.get_name()}] [started] cutting [{waiting_customer["name"]}]')
        print(f'hair_cut_time: {hair_cut_time}')

    def update_status(self):
        # if busy_stylist time exceeded finish_with_customer
        for hair_cut in self.active_hair_cuts:
            if hair_cut['time_remaining'] == 0:
                self.finish_hair_cut(hair_cut)
            else:
                hair_cut['time_remaining'] -= 1

        # if free stylist and wating customer start_next_customer
        # note: we want to do this after finishing existing hair_cuts so that a stylist can get back to work immediately!! No Slacking!!
        while self.free_stylists and self.waiting_customers:
            self.service_next_customer()

        # if waiting customer > 30 mins: customer_leaves_unfulfilled
        for waiting_customer in self.waiting_customers:
            if(waiting_customer['time_waiting']>=30):
                self.customer_leaves_unfulfilled(waiting_customer)



class Time:
    def __init__(self, hour, minute):
        self.datetime = datetime.datetime(
            year=2019, month=1, day=1, hour=hour, minute=minute)
        # self.hour = hour
        # self.minute = minute

    def current_time_to_string(self):
        return(self.datetime.strftime('%H:%M'))

    def tick_minute(self):
        self.datetime += datetime.timedelta(minutes=1)

    def is_earlier_than(self, hour, minute=0):
        return self.datetime.time() < datetime.datetime(year=2019, month=1, day=1, hour=hour, minute=minute)

    def is_hour(self, hour):
        return self.datetime.time().hour == hour

    def is_after_hour(self, hour):
        return self.datetime.time().hour >= hour

    def is_time(self, hour, minute):
        return self.datetime.time().hour == hour and self.datetime.time().minute == minute


customer_builder = CustomerBuilder()

time = Time(9, 00)
salon = HairSalon(time)
salon.open()
while True:
    if time.is_time(9, 0):
        salon.first_shift_starts()
    elif time.is_time(13, 0):
        salon.first_shift_ends()
        salon.second_shift_starts()
    elif time.is_time(17, 0):
        salon.second_shift_ends()
        break

    customer = customer_builder.try_get_new_customer()
    if customer:
        salon.customer_enter(customer)

    salon.update_status()


    time.tick_minute()

salon.close()
