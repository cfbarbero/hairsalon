# HairSalonFree

## Usage
```
python main.py
```

## Status
Time 2 hours:
This is a mostly working sample.

ToDo:
- Finish the salon close functionality.  Currently the salon will close even if there is an active hair cut.
- Add dataclasses for the waiting_customers and active_hair_cuts instead of objects